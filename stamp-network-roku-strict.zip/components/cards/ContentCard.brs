sub Init()
    m.poster = m.top.FindNode("poster")
    m.titleLabel = m.top.FindNode("titleLabel")
    m.premiumBadge = m.top.FindNode("premiumBadge")
    m.premiumLabel = m.top.FindNode("premiumLabel")
end sub

sub OnContentSet()
    content = m.top.itemContent
    if content = invalid
        return
    end if

    m.poster.uri = content.hdPosterUrl
    m.titleLabel.text = content.title

    isPremium = false
    if content.HasField("isPremium") and content.isPremium = true
        isPremium = true
    end if

    m.premiumBadge.visible = isPremium
    m.premiumLabel.visible = isPremium
end sub
