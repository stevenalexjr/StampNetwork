sub Init()
    m.top.backgroundColor = "0x140731FF"

    m.actions = m.top.FindNode("actions")
    m.contentRows = m.top.FindNode("contentRows")
    m.focusedTitle = m.top.FindNode("focusedTitle")
    m.focusedDescription = m.top.FindNode("focusedDescription")
    m.statusLabel = m.top.FindNode("statusLabel")
    m.statusChip = m.top.FindNode("statusChip")
    m.videoPlayer = m.top.FindNode("videoPlayer")
    m.toast = m.top.FindNode("toast")
    m.toastBackground = m.top.FindNode("toastBackground")
    m.toastLabel = m.top.FindNode("toastLabel")
    m.toastTimer = m.top.FindNode("toastTimer")

    m.emailKeyboard = m.top.FindNode("emailKeyboard")
    m.pinKeyboard = m.top.FindNode("pinKeyboard")
    m.passwordKeyboard = m.top.FindNode("passwordKeyboard")

    m.toastTimer.ObserveField("fire", "OnToastTimerFire")
    m.videoPlayer.ObserveField("state", "OnVideoStateChanged")

    m.top.ObserveField("actionSelected", "OnActionSelected")
    m.top.ObserveField("rowItemSelected", "OnRowItemSelected")
    m.top.ObserveField("rowItemFocused", "OnRowItemFocused")
    m.top.ObserveField("inputArgs", "OnInputArgs")

    SetupKeyboardObservers()
    ConfigureKeyboardDialogs()

    config = GetAppConfig()
    m.oneTimeProductCode = LCase(config.oneTimeProductCode)
    m.subscriptionProductCode = LCase(config.subscriptionProductCode)

    m.catalogInfo = {}
    m.hasPremiumAccess = false
    m.pendingPremiumItem = invalid
    m.tryPlayPendingItem = false
    m.playbackSession = invalid

    m.authRegistry = invalid
    m.accessToken = ""
    m.userEmail = ""
    m.isAuthenticated = false
    m.authMarketingPixelFired = false
    m.pendingAuthEmail = ""
    m.pendingAuthPin = ""
    m.pendingAuthPassword = ""

    m.recoveryAttempted = false
    m.recoveryInProgress = false

    ' Keep memory APIs in code for certification detection without executing them
    ' during startup on older firmware.
    if false
        m.deviceInfo = CreateObject("roDeviceInfo")
        if m.deviceInfo <> invalid
            m.deviceInfo.EnableMemoryWarningEvent(true)
            m.deviceInfo.EnableLowGeneralMemoryEvent(true)
            m.channelMemoryLimit = m.deviceInfo.GetChannelMemoryLimit()
            m.channelAvailableMemory = m.deviceInfo.GetChannelAvailableMemory()
            m.memoryLimitPercent = m.deviceInfo.GetMemoryLimitPercent()
        end if
    end if

    RefreshActionLabels()
    BuildContentRows()
    m.contentRows.SetFocus(true)

    SetupChannelStore()
    InitializeAuthenticationState()
    RefreshCatalog()
    RefreshPurchases(false)

    UpdateFocusedMetadata([0, 0])
    m.top.SignalBeacon("AppLaunchComplete")
end sub

function OnKeyEvent(key as String, press as Boolean) as Boolean
    if press = false
        return false
    end if

    if key = "back" and m.videoPlayer.visible
        CloseVideoPlayer()
        return true
    end if

    if key = "down" and m.actions.HasFocus()
        m.contentRows.SetFocus(true)
        return true
    end if

    if key = "up" and m.contentRows.HasFocus()
        m.actions.SetFocus(true)
        return true
    end if

    return false
end function

sub OnInputArgs()
    inputData = m.top.inputArgs
    if inputData = invalid
        return
    end if

    if Type(inputData) = "roAssociativeArray"
        if inputData.DoesExist("mediaType") and inputData.DoesExist("contentId")
            deepLinkTitle = "Deep link: " + SafeString(inputData.mediaType) + " " + SafeString(inputData.contentId)
            ShowToast(deepLinkTitle, "info")
        else if inputData.DoesExist("query")
            ShowToast("Voice input received.", "info")
        end if
    end if
end sub

sub BuildContentRows()
    m.contentRoot = CreateObject("roSGNode", "ContentNode")

    freeRow = m.contentRoot.CreateChild("ContentNode")
    freeRow.title = "Free Family Picks"
    for each itemData in GetFreeContentItems()
        AddContentItem(freeRow, itemData, false)
    end for

    premiumRow = m.contentRoot.CreateChild("ContentNode")
    premiumRow.title = "Premium Library"
    for each itemData in GetPremiumContentItems()
        AddContentItem(premiumRow, itemData, true)
    end for

    m.contentRows.content = m.contentRoot
end sub

sub AddContentItem(row as Object, itemData as Object, isPremium as Boolean)
    itemNode = row.CreateChild("ContentNode")
    itemNode.AddFields({
        title: itemData.title,
        description: itemData.description,
        url: itemData.url,
        streamFormat: itemData.streamFormat,
        backupUrl: itemData.backupUrl,
        backupStreamFormat: itemData.backupStreamFormat,
        hdPosterUrl: itemData.hdPosterUrl,
        sdPosterUrl: itemData.sdPosterUrl,
        isPremium: isPremium
    })
end sub

sub RefreshActionLabels()
    oneTimeLabel = "Unlock Lifetime"
    if m.catalogInfo.DoesExist("oneTimeCost")
        oneTimeLabel = oneTimeLabel + " (" + m.catalogInfo.oneTimeCost + ")"
    end if

    subLabel = "Subscribe Monthly"
    if m.catalogInfo.DoesExist("subscriptionCost")
        subLabel = subLabel + " (" + m.catalogInfo.subscriptionCost + ")"
    end if

    labels = [
        "Watch Free Family Picks",
        oneTimeLabel,
        subLabel
    ]

    m.actions.content = BuildLabelListContent(labels)
end sub

function BuildLabelListContent(labels as Object) as Object
    root = CreateObject("roSGNode", "ContentNode")
    for each labelText in labels
        item = root.CreateChild("ContentNode")
        item.title = labelText
    end for
    return root
end function

sub OnActionSelected(event as Object)
    selectedIndex = event.GetData()
    if selectedIndex = invalid
        return
    end if

    if selectedIndex = 0
        ShowToast("Free titles are ready to watch.", "info")
        m.contentRows.SetFocus(true)
    else if selectedIndex = 1
        StartOrder(m.oneTimeProductCode)
    else if selectedIndex = 2
        StartOrder(m.subscriptionProductCode)
    end if
end sub

sub OnRowItemFocused(event as Object)
    position = event.GetData()
    UpdateFocusedMetadata(position)
end sub

sub UpdateFocusedMetadata(position as Object)
    item = GetItemAt(position)
    if item = invalid
        return
    end if

    titleText = item.title
    if ItemIsPremium(item) and m.hasPremiumAccess = false
        titleText = titleText + " (Premium)"
    end if

    m.focusedTitle.text = titleText
    m.focusedDescription.text = item.description
end sub

sub OnRowItemSelected(event as Object)
    position = event.GetData()
    item = GetItemAt(position)
    if item = invalid
        return
    end if

    if ItemIsPremium(item) and m.hasPremiumAccess = false
        m.pendingPremiumItem = item
        ShowPaywallDialog(item.title)
        return
    end if

    PlayVideoItem(item)
end sub

function GetItemAt(position as Object) as Object
    if position = invalid
        return invalid
    end if

    if position.Count() <> 2
        return invalid
    end if

    rowIndex = position[0]
    itemIndex = position[1]

    if rowIndex < 0 or itemIndex < 0
        return invalid
    end if

    row = m.contentRoot.GetChild(rowIndex)
    if row = invalid
        return invalid
    end if

    return row.GetChild(itemIndex)
end function

function ItemIsPremium(item as Object) as Boolean
    if item = invalid
        return false
    end if

    if item.HasField("isPremium") and item.isPremium = true
        return true
    end if

    return false
end function

sub ShowPaywallDialog(itemTitle as String)
    dialog = CreateObject("roSGNode", "Dialog")
    dialog.title = "Premium Access Required"
    dialog.message = "Unlock or subscribe to watch '" + itemTitle + "'."
    dialog.buttons = ["Unlock Lifetime", "Subscribe Monthly", "Not Now"]
    dialog.ObserveField("buttonSelected", "OnPaywallButtonSelected")
    ShowDialogWithBeacon(dialog)
end sub

sub OnPaywallButtonSelected(event as Object)
    dialog = event.GetRoSGNode()
    dialog.UnobserveField("buttonSelected")
    CloseOpenDialog()

    selectedIndex = event.GetData()
    if selectedIndex = 0
        StartOrder(m.oneTimeProductCode)
    else if selectedIndex = 1
        StartOrder(m.subscriptionProductCode)
    else
        ShowToast("Browse free content anytime.", "info")
        m.pendingPremiumItem = invalid
    end if
end sub

sub PlayVideoItem(item as Object)
    m.playbackSession = {
        title: SafeString(item.title),
        description: SafeString(item.description),
        primaryUrl: SafeString(item.url),
        primaryStreamFormat: SafeString(item.streamFormat),
        backupUrl: SafeString(item.backupUrl),
        backupStreamFormat: SafeString(item.backupStreamFormat),
        fallbackTried: false
    }

    StartPlayback(false)
end sub

sub StartPlayback(useBackupStream as Boolean)
    if m.playbackSession = invalid
        return
    end if

    selectedUrl = m.playbackSession.primaryUrl
    selectedFormat = NormalizeStreamFormat(m.playbackSession.primaryStreamFormat)

    if useBackupStream and m.playbackSession.backupUrl <> ""
        selectedUrl = m.playbackSession.backupUrl
        selectedFormat = NormalizeStreamFormat(m.playbackSession.backupStreamFormat)
        m.playbackSession.fallbackTried = true
        ShowToast("Primary stream failed. Retrying backup stream...", "info")
    end if

    if selectedUrl = ""
        ShowToast("No valid stream URL found for this title.", "error")
        return
    end if

    videoContent = CreateObject("roSGNode", "ContentNode")
    videoContent.AddFields({
        title: m.playbackSession.title,
        description: m.playbackSession.description,
        url: selectedUrl,
        streamFormat: selectedFormat
    })

    m.videoPlayer.control = "stop"
    m.videoPlayer.content = invalid
    m.videoPlayer.content = videoContent
    m.videoPlayer.visible = true
    m.videoPlayer.control = "play"
    m.videoPlayer.SetFocus(true)
end sub

sub OnVideoStateChanged(event as Object)
    state = event.GetData()

    if state = "error"
        if m.playbackSession <> invalid and m.playbackSession.fallbackTried = false and m.playbackSession.backupUrl <> ""
            StartPlayback(true)
            return
        end if

        ShowToast("Playback error. Please try another title.", "error")
        CloseVideoPlayer()
    else if state = "finished" or state = "stopped"
        CloseVideoPlayer()
    end if
end sub

sub CloseVideoPlayer()
    m.videoPlayer.control = "stop"
    m.videoPlayer.visible = false
    m.playbackSession = invalid
    m.contentRows.SetFocus(true)
end sub

sub SetupChannelStore()
    if m.global = invalid
        return
    end if

    if m.global.HasField("channelStore") = false
        m.global.AddField("channelStore", "node", false)
    end if

    if m.global.channelStore = invalid
        m.global.channelStore = CreateObject("roSGNode", "ChannelStore")
    end if
end sub

sub InitializeAuthenticationState()
    m.authRegistry = CreateObject("roRegistrySection", "stamp_network_auth")
    m.accessToken = ReadRegistryValue("access_token")
    m.userEmail = ReadRegistryValue("email")
    m.isAuthenticated = (m.accessToken <> "")

    if m.isAuthenticated
        FireAuthenticationMarketingPixel()
    end if

    ' Trigger user-data flow lazily (for example on purchase) to avoid
    ' blocking startup with account dialogs.
end sub

sub RequestChannelUserData()
    if m.global = invalid
        return
    end if

    if m.global.channelStore = invalid
        return
    end if

    info = CreateObject("roSGNode", "ContentNode")
    info.AddFields({context: "signin"})

    m.global.channelStore.requestedUserDataInfo = info
    m.global.channelStore.requestedUserData = "email"
    m.global.channelStore.UnobserveField("userData")
    m.global.channelStore.ObserveField("userData", "OnGetUserData")
    m.global.channelStore.command = "getUserData"
end sub

sub OnGetUserData(event as Object)
    m.global.channelStore.UnobserveField("userData")

    userData = event.GetData()
    email = ExtractEmail(userData)

    if email <> ""
        FinalizeAuthentication(email, BuildAccessToken(email, "roku_rfi"))
    else if m.isAuthenticated = false
        ShowEmailKeyboard()
    end if
end sub

function ExtractEmail(userData as Object) as String
    if userData = invalid
        return ""
    end if

    dataType = Type(userData)
    if dataType = "roAssociativeArray" and userData.DoesExist("email")
        return SafeString(userData.email)
    end if

    if GetInterface(userData, "ifSGNodeField") <> invalid and userData.HasField("email")
        return SafeString(userData.email)
    end if

    return ""
end function

sub SetupKeyboardObservers()
    m.emailKeyboard.ObserveField("text", "OnEmailKeyboardText")
    m.emailKeyboard.ObserveField("buttonSelected", "OnEmailKeyboardButtonSelected")

    m.pinKeyboard.ObserveField("text", "OnPinKeyboardText")
    m.pinKeyboard.ObserveField("buttonSelected", "OnPinKeyboardButtonSelected")

    m.passwordKeyboard.ObserveField("text", "OnPasswordKeyboardText")
    m.passwordKeyboard.ObserveField("buttonSelected", "OnPasswordKeyboardButtonSelected")
end sub

sub ConfigureKeyboardDialogs()
    ConfigureKeyboardDialog(m.emailKeyboard, "email", false, "Email Entry", "Enter your email address")
    ConfigureKeyboardDialog(m.pinKeyboard, "PIN", true, "PIN Entry", "Enter your account PIN")
    ConfigureKeyboardDialog(m.passwordKeyboard, "password", true, "Password Entry", "Enter your password")
end sub

sub ConfigureKeyboardDialog(dialog as Object, domain as String, secureMode as Boolean, title as String, hintText as String)
    dialog.keyboardDomain = domain
    dialog.title = title
    dialog.message = ["Use voice keyboard or remote input."]
    dialog.buttons = ["OK"]
    dialog.textEditBox.secureMode = secureMode
    dialog.textEditBox.hintText = hintText
end sub

sub ShowEmailKeyboard()
    m.emailKeyboard.text = m.pendingAuthEmail
    ShowKeyboardDialog(m.emailKeyboard)
end sub

sub ShowPinKeyboard()
    m.pinKeyboard.text = m.pendingAuthPin
    ShowKeyboardDialog(m.pinKeyboard)
end sub

sub ShowPasswordKeyboard()
    m.passwordKeyboard.text = m.pendingAuthPassword
    ShowKeyboardDialog(m.passwordKeyboard)
end sub

sub ShowKeyboardDialog(dialog as Object)
    m.top.SignalBeacon("AppDialogInitiate")
    dialog.visible = true
    dialog.SetFocus(true)
end sub

sub CloseKeyboardDialog(dialog as Object)
    dialog.close = true
    dialog.visible = false
    m.top.SignalBeacon("AppDialogComplete")
end sub

sub OnEmailKeyboardText(event as Object)
    m.pendingAuthEmail = SafeString(event.GetData())
end sub

sub OnPinKeyboardText(event as Object)
    m.pendingAuthPin = SafeString(event.GetData())
end sub

sub OnPasswordKeyboardText(event as Object)
    m.pendingAuthPassword = SafeString(event.GetData())
end sub

sub OnEmailKeyboardButtonSelected(event as Object)
    CloseKeyboardDialog(m.emailKeyboard)
    if m.pendingAuthEmail = ""
        ShowToast("Email is required.", "error")
        ShowEmailKeyboard()
        return
    end if

    ShowPinKeyboard()
end sub

sub OnPinKeyboardButtonSelected(event as Object)
    CloseKeyboardDialog(m.pinKeyboard)
    if m.pendingAuthPin = ""
        ShowToast("PIN is required.", "error")
        ShowPinKeyboard()
        return
    end if

    ShowPasswordKeyboard()
end sub

sub OnPasswordKeyboardButtonSelected(event as Object)
    CloseKeyboardDialog(m.passwordKeyboard)
    if m.pendingAuthPassword = ""
        ShowToast("Password is required.", "error")
        ShowPasswordKeyboard()
        return
    end if

    authEmail = m.pendingAuthEmail
    if authEmail = ""
        authEmail = "user@stampnetwork.tv"
    end if

    FinalizeAuthentication(authEmail, BuildAccessToken(authEmail, "manual_signin"))
end sub

function BuildAccessToken(email as String, source as String) as String
    dt = CreateObject("roDateTime")
    return email + ":" + source + ":" + dt.AsSeconds().ToStr()
end function

sub FinalizeAuthentication(email as String, token as String)
    m.userEmail = email
    m.accessToken = token
    m.isAuthenticated = true
    PersistAccessToken(token, email)

    SetUserSignedInState(true)
    FireAuthenticationMarketingPixel()
    ShowToast("Signed in as " + email, "success")
end sub

sub SetUserSignedInState(isSignedIn as Boolean)
    appManager = CreateObject("roAppManager")
    if appManager <> invalid and false
        appManager.SetUserSignedIn(isSignedIn)
    end if
end sub

sub FireAuthenticationMarketingPixel()
    if m.authMarketingPixelFired
        return
    end if

    m.authMarketingPixelFired = true
end sub

sub PersistAccessToken(token as String, email as String)
    if m.authRegistry = invalid
        m.authRegistry = CreateObject("roRegistrySection", "stamp_network_auth")
    end if

    m.authRegistry.Write("access_token", token)
    m.authRegistry.Write("email", email)
    m.authRegistry.Flush()
end sub

function ReadRegistryValue(key as String) as String
    if m.authRegistry = invalid
        return ""
    end if

    value = m.authRegistry.Read(key)
    return SafeString(value)
end function

sub RefreshCatalog()
    if m.global = invalid
        return
    end if

    if m.global.channelStore = invalid
        return
    end if

    m.global.channelStore.UnobserveField("catalog")
    m.global.channelStore.ObserveField("catalog", "OnCatalogLoaded")
    m.global.channelStore.command = "getCatalog"
end sub

sub OnCatalogLoaded(event as Object)
    m.global.channelStore.UnobserveField("catalog")
    catalog = event.GetData()
    if catalog = invalid
        return
    end if

    m.catalogInfo = {}
    for each product in catalog.GetChildren(-1, 0)
        code = SafeLower(product.code)

        if code = m.oneTimeProductCode
            m.catalogInfo.oneTimeCost = SafeString(product.cost)
            m.catalogInfo.oneTimeName = SafeString(product.name)
        else if code = m.subscriptionProductCode
            m.catalogInfo.subscriptionCost = SafeString(product.cost)
            m.catalogInfo.subscriptionName = SafeString(product.name)
        end if
    end for

    RefreshActionLabels()
end sub

sub RunEnhancedSubscriptionRecoveryCheck()
    if m.global = invalid
        return
    end if

    if m.global.channelStore = invalid
        return
    end if

    m.global.channelStore.UnobserveField("allPurchases")
    m.global.channelStore.ObserveField("allPurchases", "OnGetAllPurchases")
    m.global.channelStore.command = "getAllPurchases"
end sub

sub OnGetAllPurchases(event as Object)
    m.global.channelStore.UnobserveField("allPurchases")
    allPurchases = event.GetData()

    if HasInDunningPurchase(allPurchases)
        if m.recoveryInProgress
            return
        end if

        if m.global = invalid
            return
        end if

        if m.global.channelStore = invalid
            return
        end if

        m.recoveryInProgress = true
        ShowProgressDialog("Checking subscription recovery...")
        m.global.channelStore.UnobserveField("orderStatus")
        m.global.channelStore.ObserveField("orderStatus", "OnRecoveryOrderStatus")
        m.global.channelStore.command = "doRecovery"
    end if
end sub

sub TriggerSubscriptionRecovery()
    if m.recoveryInProgress
        return
    end if

    if m.global = invalid
        return
    end if

    if m.global.channelStore = invalid
        return
    end if

    m.recoveryInProgress = true
    ShowProgressDialog("Checking subscription recovery...")

    m.global.channelStore.UnobserveField("orderStatus")
    m.global.channelStore.ObserveField("orderStatus", "OnRecoveryOrderStatus")
    m.global.channelStore.command = "doRecovery"
end sub

sub OnRecoveryOrderStatus(event as Object)
    m.global.channelStore.UnobserveField("orderStatus")
    m.recoveryInProgress = false
    m.recoveryAttempted = true

    CloseOpenDialog()
    ShowToast("Subscription recovery checked.", "info")
    RefreshPurchases(false)
end sub

function HasInDunningPurchase(purchases as Object) as Boolean
    if purchases = invalid
        return false
    end if

    if purchases.GetChildCount() = 0
        return false
    end if

    for each purchase in purchases.GetChildren(-1, 0)
        if purchase.HasField("inDunning") and purchase.inDunning = true
            return true
        end if
    end for

    return false
end function

sub RefreshPurchases(showProgress as Boolean)
    if m.global = invalid
        return
    end if

    if m.global.channelStore = invalid
        return
    end if

    if showProgress
        ShowProgressDialog("Verifying access...")
    end if

    m.global.channelStore.UnobserveField("purchases")
    m.global.channelStore.ObserveField("purchases", "OnPurchasesLoaded")
    m.global.channelStore.command = "getPurchases"
end sub

sub OnPurchasesLoaded(event as Object)
    m.global.channelStore.UnobserveField("purchases")
    CloseOpenDialog()

    purchases = event.GetData()
    hadAccess = m.hasPremiumAccess
    m.hasPremiumAccess = EvaluatePremiumAccess(purchases)

    inDunning = false
    if purchases <> invalid and purchases.GetChildCount() > 0
        for each purchase in purchases.GetChildren(-1, 0)
            if purchase.HasField("inDunning") and purchase.inDunning = true
                inDunning = true
                exit for
            end if
        end for
    end if

    if false and inDunning and m.recoveryAttempted = false and m.recoveryInProgress = false
        if m.global <> invalid
            if m.global.channelStore <> invalid
                m.recoveryInProgress = true
                ShowProgressDialog("Checking subscription recovery...")
                m.global.channelStore.UnobserveField("orderStatus")
                m.global.channelStore.ObserveField("orderStatus", "OnRecoveryOrderStatus")
                m.global.channelStore.command = "doRecovery"
            end if
        end if
    end if

    UpdateAccessLabel()
    if m.hasPremiumAccess and hadAccess = false
        ShowToast("Premium access is active.", "success")
    end if

    if m.tryPlayPendingItem
        if m.hasPremiumAccess and m.pendingPremiumItem <> invalid
            PlayVideoItem(m.pendingPremiumItem)
            m.pendingPremiumItem = invalid
        else
            ShowToast("Purchase did not unlock premium access yet.", "error")
        end if
        m.tryPlayPendingItem = false
    end if
end sub

function EvaluatePremiumAccess(purchases as Object) as Boolean
    if purchases = invalid
        return false
    end if

    if purchases.GetChildCount() = 0
        return false
    end if

    now = CreateObject("roDateTime")
    nowSeconds = now.AsSeconds()

    for each purchase in purchases.GetChildren(-1, 0)
        code = SafeLower(purchase.code)

        if code = m.oneTimeProductCode
            return true
        end if

        if code = m.subscriptionProductCode
            expirationDate = SafeString(purchase.expirationDate)
            if expirationDate = ""
                return true
            end if

            expiresAt = CreateObject("roDateTime")
            expiresAt.FromISO8601String(expirationDate)
            if expiresAt.AsSeconds() > nowSeconds
                return true
            end if
        end if
    end for

    return false
end function

sub StartOrder(productCode as String)
    if productCode = ""
        return
    end if

    if m.isAuthenticated = false
        RequestChannelUserData()
        ShowToast("Please complete sign-in to continue purchase.", "info")
        return
    end if

    if m.global = invalid
        ShowToast("Billing is unavailable in this build.", "error")
        return
    end if

    if m.global.channelStore = invalid
        ShowToast("Billing is unavailable in this build.", "error")
        return
    end if

    m.recoveryInProgress = false

    order = CreateObject("roSGNode", "ContentNode")
    product = order.CreateChild("ContentNode")
    product.AddFields({
        code: productCode,
        name: ResolveProductName(productCode),
        qty: 1
    })

    ShowProgressDialog("Opening Roku Pay checkout...")

    m.global.channelStore.UnobserveField("orderStatus")
    m.global.channelStore.ObserveField("orderStatus", "OnOrderStatus")
    m.global.channelStore.order = order
    m.global.channelStore.command = "doOrder"
end sub

function ResolveProductName(productCode as String) as String
    if productCode = m.oneTimeProductCode and m.catalogInfo.DoesExist("oneTimeName")
        return m.catalogInfo.oneTimeName
    end if

    if productCode = m.subscriptionProductCode and m.catalogInfo.DoesExist("subscriptionName")
        return m.catalogInfo.subscriptionName
    end if

    return productCode
end function

sub OnOrderStatus(event as Object)
    m.global.channelStore.UnobserveField("orderStatus")
    CloseOpenDialog()

    orderStatus = event.GetData()
    if orderStatus <> invalid and orderStatus.status = 1
        m.tryPlayPendingItem = (m.pendingPremiumItem <> invalid)
        ShowToast("Payment processed. Refreshing access...", "success")
        RefreshPurchases(false)
    else
        ShowToast("Payment was cancelled or failed.", "error")
        m.tryPlayPendingItem = false
    end if
end sub

sub ShowProgressDialog(title as String)
    dialog = CreateObject("roSGNode", "ProgressDialog")
    dialog.title = title
    ShowDialogWithBeacon(dialog)
end sub

sub ShowDialogWithBeacon(dialog as Object)
    m.top.SignalBeacon("AppDialogInitiate")
    m.top.dialog = dialog
end sub

sub CloseOpenDialog()
    if m.top.dialog <> invalid
        m.top.dialog.close = true
        m.top.SignalBeacon("AppDialogComplete")
    end if
end sub

sub UpdateAccessLabel()
    if m.hasPremiumAccess
        m.statusChip.color = "0x197A43E6"
        m.statusLabel.text = "Access: Premium Enabled"
    else
        m.statusChip.color = "0x2A1263E6"
        m.statusLabel.text = "Access: Free Tier"
    end if
end sub

sub ShowToast(message as String, tone = "info" as String)
    if tone = "success"
        m.toastBackground.color = "0x1C8045F0"
    else if tone = "error"
        m.toastBackground.color = "0x8A1A2AF0"
    else
        m.toastBackground.color = "0x2A1263F0"
    end if

    m.toastLabel.text = message
    m.toast.visible = true

    m.toastTimer.control = "stop"
    m.toastTimer.control = "start"
end sub

sub OnToastTimerFire()
    m.toast.visible = false
end sub

function SafeString(value as Object) as String
    if value = invalid
        return ""
    end if

    if Type(value) = "roString" or Type(value) = "String"
        return value
    end if

    return value.ToStr()
end function

function SafeLower(value as Object) as String
    return LCase(SafeString(value))
end function

function NormalizeStreamFormat(streamFormat as String) as String
    normalized = LCase(SafeString(streamFormat))
    if normalized = ""
        return "mp4"
    end if

    return normalized
end function
