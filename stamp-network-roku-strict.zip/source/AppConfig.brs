function GetAppConfig() as Object
    return {
        oneTimeProductCode: "stamp_lifetime_unlock",
        subscriptionProductCode: "stamp_monthly_subscription"
    }
end function
