function GetFreeContentItems() as Object
    items = []

    items.Push({
        title: "Backyard Campout",
        description: "A fun outdoor adventure for the whole family.",
        url: "https://devtools.web.roku.com/samples/video/rr/117_segment_2_twitch__nw_060515.mp4",
        streamFormat: "mp4",
        backupUrl: "https://devtools.web.roku.com/samples/video/rr/roku_ep_115_segment_5_paula_nw_050515.mp4",
        backupStreamFormat: "mp4",
        hdPosterUrl: "pkg:/images/posters/backyard-campout.png",
        sdPosterUrl: "pkg:/images/posters/backyard-campout.png"
    })

    items.Push({
        title: "Storytime Station",
        description: "Gentle stories and creative play for younger viewers.",
        url: "https://devtools.web.roku.com/samples/video/rr/roku_ep_115_segment_1_ted_nw_050515.mp4",
        streamFormat: "mp4",
        backupUrl: "https://devtools.web.roku.com/samples/video/rr/ep-126-seg-3_contv_v1-mo.mp4",
        backupStreamFormat: "mp4",
        hdPosterUrl: "pkg:/images/posters/storytime-station.png",
        sdPosterUrl: "pkg:/images/posters/storytime-station.png"
    })

    items.Push({
        title: "Family Build Lab",
        description: "DIY-inspired segments to watch and try together.",
        url: "https://devtools.web.roku.com/samples/video/rr/roku_119_segment_2_062315.mp4",
        streamFormat: "mp4",
        backupUrl: "https://devtools.web.roku.com/samples/video/rr/rr_ep_124_segment_2_080315_h264.mp4",
        backupStreamFormat: "mp4",
        hdPosterUrl: "pkg:/images/posters/family-build-lab.png",
        sdPosterUrl: "pkg:/images/posters/family-build-lab.png"
    })

    items.Push({
        title: "Creative Kitchen",
        description: "Kid-friendly cooking fun and easy at-home recipes.",
        url: "https://devtools.web.roku.com/samples/video/rr/ep-123-seq-4-nick-alt_081215.mp4",
        streamFormat: "mp4",
        backupUrl: "https://devtools.web.roku.com/samples/video/rr/rr_125_segment_4_080715.mp4",
        backupStreamFormat: "mp4",
        hdPosterUrl: "pkg:/images/posters/creative-kitchen.png",
        sdPosterUrl: "pkg:/images/posters/creative-kitchen.png"
    })

    return items
end function

function GetPremiumContentItems() as Object
    items = []

    items.Push({
        title: "Shadow Trax Originals",
        description: "Premium original series made for family co-viewing.",
        url: "https://devtools.web.roku.com/samples/video/rr/rr_ep21_segment_1_071515.mp4",
        streamFormat: "mp4",
        backupUrl: "https://devtools.web.roku.com/samples/video/rr/rr_123_segment_1_072715.mp4",
        backupStreamFormat: "mp4",
        hdPosterUrl: "pkg:/images/posters/shadow-trax-originals.png",
        sdPosterUrl: "pkg:/images/posters/shadow-trax-originals.png"
    })

    items.Push({
        title: "Weekend Movie Night",
        description: "Feature-length family picks curated every week.",
        url: "https://devtools.web.roku.com/samples/video/rr/the-affair-s2-tune-in-post-premiere---roku-with-dominic-read.mp4",
        streamFormat: "mp4",
        backupUrl: "https://devtools.web.roku.com/samples/video/rr/roku-recommends_new.mp4",
        backupStreamFormat: "mp4",
        hdPosterUrl: "pkg:/images/posters/weekend-movie-night.png",
        sdPosterUrl: "pkg:/images/posters/weekend-movie-night.png"
    })

    items.Push({
        title: "Adventure Club",
        description: "Explore nature, science, and discovery as a family.",
        url: "https://devtools.web.roku.com/samples/video/rr/pta.mp4",
        streamFormat: "mp4",
        backupUrl: "https://devtools.web.roku.com/samples/video/rr/roku_ep_113_segment_3_college_insiders_042415.mp4",
        backupStreamFormat: "mp4",
        hdPosterUrl: "pkg:/images/posters/adventure-club.png",
        sdPosterUrl: "pkg:/images/posters/adventure-club.png"
    })

    items.Push({
        title: "Family Talent Stage",
        description: "Music, dance, and creative spotlights from around the world.",
        url: "https://devtools.web.roku.com/samples/video/rr/roku_ep_115_segment_3_ufc_nw_051815.mp4",
        streamFormat: "mp4",
        backupUrl: "https://devtools.web.roku.com/samples/video/rr/rr_ep_124_segment_2_080315_h264.mp4",
        backupStreamFormat: "mp4",
        hdPosterUrl: "pkg:/images/posters/family-talent-stage.png",
        sdPosterUrl: "pkg:/images/posters/family-talent-stage.png"
    })

    return items
end function
