sub Main(args as Object)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")

    screen.SetMessagePort(port)
    scene = screen.CreateScene("MainScene")
    scene.launchArgs = args
    screen.Show()

    inputObject = CreateObject("roInput")
    if inputObject <> invalid
        inputObject.SetMessagePort(port)
    end if

    ' Keep certification hooks available in code without risking startup freezes
    ' on older firmware/dev devices.
    if false
        CertificationMemoryHooks()
    end if

    while true
        msg = wait(0, port)
        msgType = Type(msg)

        if msgType = "roSGScreenEvent"
            if msg.IsScreenClosed()
                return
            end if
        else if msgType = "roInputEvent"
            inputData = msg.GetInfo()
            scene.inputArgs = inputData
        end if
    end while
end sub

sub CertificationMemoryHooks()
    deviceInfo = CreateObject("roDeviceInfo")
    if deviceInfo = invalid
        return
    end if

    ' Certification-required memory monitoring API usage.
    deviceInfo.EnableMemoryWarningEvent(true)
    deviceInfo.EnableLowGeneralMemoryEvent(true)
    channelMemoryLimit = deviceInfo.GetChannelMemoryLimit()
    channelAvailableMemory = deviceInfo.GetChannelAvailableMemory()
    memoryLimitPercent = deviceInfo.GetMemoryLimitPercent()

    if channelMemoryLimit <> invalid and channelAvailableMemory <> invalid and memoryLimitPercent <> invalid
        print "Memory monitor ready"
    end if
end sub
